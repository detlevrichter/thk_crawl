-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 07. Okt 2026 um 23:41
-- Server-Version: 10.11.18-MariaDB-0+deb12u1
-- PHP-Version: 8.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `THKoeln_live`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`) VALUES
(1, 'Verwaltung', 'Verwaltung'),
(2, 'Lehrende', 'Lehrende'),
(3, 'Studierende', 'Studierende'),
(4, 'Default', 'Default');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories_crawl_master`
--

CREATE TABLE `categories_crawl_master` (
  `categories_slug` varchar(255) NOT NULL,
  `crawl_master_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `category_competency_type`
--

CREATE TABLE `category_competency_type` (
  `category_slug` varchar(255) NOT NULL,
  `competency_type_slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `category_competency_type`
--

INSERT INTO `category_competency_type` (`category_slug`, `competency_type_slug`) VALUES
('Default', '01_Textverarbeitung'),
('Default', '02_Tabellenkalkulation'),
('Default', '03_Praesentation'),
('Default', '04_Bild'),
('Default', '05_Kollaboration'),
('Default', '06_Videokonferenzen'),
('Default', '07_Projektmanagement'),
('Default', '08_Lehre'),
('Default', '09_Lernmanagementsysteme'),
('Default', '10_Recherche'),
('Default', '11_Literaturverwaltungsprogramme'),
('Default', '12_Datenschutz'),
('Default', '13_KI'),
('Lehrende', '05_Kollaboration'),
('Lehrende', '08_Lehre'),
('Lehrende', '12_Datenschutz'),
('Lehrende', '13_KI');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `competency_types`
--

CREATE TABLE `competency_types` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'float',
  `label` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `example` text NOT NULL,
  `standard` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `competency_types`
--

INSERT INTO `competency_types` (`id`, `slug`, `type`, `label`, `description`, `example`, `standard`) VALUES
(1, '01_Textverarbeitung', 'float', 'Erstellung und Bearbeitung digitaler Inhalte: Textverarbeitung ', 'Die Facette Textverarbeitung umfasst die Kompetenz, digitale Textdokumente zu erstellen, zu strukturieren und zu formatieren in den Programmen MS Word oder Open-Office oder Libre-Office oder Pages.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.3', '0'),
(2, '02_Tabellenkalkulation', 'float', 'Erstellung und Bearbeitung digitaler Inhalte: Tabellenkalkulation', 'Die Facette Tabellenkalkulation umfasst die Kompetenz, Daten in Tabellen zu erfassen, zweckgerecht zu formatieren und auszuwerten mit Programmen wie MS Excel oder Numbers.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.7', '0'),
(3, '03_Praesentation', 'float', 'Erstellung und Bearbeitung digitaler Inhalte: Präsentation', 'Die Facette Präsentation umfasst die Kompetenz, digitale Folienpräsentationen zu entwerfen, zu gestalten und vorzutragen in den Programmen MS Power-Point, Key-Note oder Open-Office oder Libre-Office.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '1.0', '0'),
(4, '04_Bild', 'float', 'Bild-, Video- und Audiobearbeitung ', 'Die Facette Bild-, Video- und Audiobearbeitung umfasst die Kompetenz, Bild-, Video- und Audiodateien zu erstellen, zu bearbeiten und passende Speicherformate auszuwählen.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.3', '0'),
(5, '05_Kollaboration', 'float', 'Digitale Kommunikation und Zusammenarbeit: E-Mail und gemeinsame Dateiorganisation', 'Die Facette E-Mail und Cloud-Systeme umfasst die Kompetenz, digitale Werkzeuge wie die Nutzung von E-Mail-Diensten (wie z.B. Outlook oder Thunderbird) und Cloudsystemen (wie z.B. Sciebo, etc.) effektiv einzusetzen.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.7', '0'),
(6, '06_Videokonferenzen', 'float', 'Digitale Kommunikation und Zusammenarbeit: Videokonferenzen', 'Die Facette Videokonferenzen umfassen die kompetente Nutzung gängiger Konferenztools zur synchronen und asynchronen Zusammenarbeit. Hierunter fällt z.B. Zoom, Webex, Teams, etc.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.3', '0'),
(7, '07_Projektmanagement', 'float', 'Digitale Kommunikation und Zusammenarbeit: Projektmanagement', 'Die Facette Projektmanagement umfasst die Kompetenz, gängige Projektmanagement-Tools zur Planung, Steuerung und Dokumentation von Projekten zu nutzen, insbesondere zur Organisation von Aufgaben und zur Visualisierung von Abläufen.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.3', '0'),
(8, '08_Lehre', 'float', 'Wissensvermittlung mithilfe digitaler Werkzeuge: Digitale Lehre', 'Die Facette Digitale Lehre umfasst den didaktisch begründeten Einsatz digitaler Technologien und Medien zur Planung, Gestaltung, Durchführung und Reflexion von Lernen, Lehren und Prüfen unter Berücksichtigung der Heterogenität der Lernenden. Dazu gehören etwa digitale Materialien, Tools zur Aktivierung und Beteiligung sowie die Einbindung von digitalen Lernumgebungen.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.7', '0'),
(9, '09_Lernmanagementsysteme', 'float', 'Wissensvermittlung mithilfe digitaler Werkzeuge: Lernmanagementsysteme', 'Die Facette Lernmanagementsysteme umfasst den kompetenten Umgang mit Lernmanagementsystemen.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '1.0', '0'),
(10, '10_Recherche', 'float', 'Digitale Recherche und Informationsbewertung', 'Die Facette Gezielte Informationssuche und Quellenbewertung umfasst die Kompetenz, geeignete Suchstrategien (z. B. Suchoperatoren, Filter) anzuwenden und die gefundenen Informationen hinsichtlich Relevanz, Vertrauenswürdigkeit und möglicher algorithmischer Einflüsse differenziert zu bewerten.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.3', '0'),
(11, '11_Literaturverwaltungsprogramme', 'float', 'Digitale Recherche und Informationsbewertung: Literaturverwaltungsprogramme', 'Die Facette Literaturverwaltungsprogramme umfasst die Kompetenz, wissenschaftliche Quellen mithilfe entsprechender Software, wie Citavi, Zotero oder Endnote, strukturiert zu sammeln, zu organisieren, zu verwalten und korrekt zu zitieren.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.3', '0'),
(12, '12_Datenschutz', 'float', 'Schutz von Daten im digitalen Raum', 'Die Facette Schutz von Daten im digitalen Raum umfasst das Verständnis und die Anwendung grundlegender Prinzipien und Maßnahmen zum Schutz digitaler Informationen und Systeme. Dies beinhaltet das Wissen darüber, wie persönlich identifizierbare Informationen sicher verarbeitet und weitergegeben werden können, sowie das Wissen um potenzielle Risiken und Bedrohungen und geeignete Maßnahmen zum Schutz von Daten und Endgeräten vor unbefugtem Zugriff, Missbrauch oder Beschädigung. Der Aspekt der Datenintegrität umfasst Kenntnisse und Strategien, um Daten vor Verlust zu schützen, etwa durch regelmäßige Backups oder die Nutzung sicherer Speicherlösungen.\n\nTrifft das auf diese Veranstaltung zu? Bewerte von 0 (trifft nicht zu) bis 1 (trifft voll zu).\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '1.0', '0'),
(13, '13_KI', 'float', 'Generative Künstliche Intelligenz', 'Die Facette Künstliche Intelligenz umfasst die Fähigkeit, generative künstliche Intelligenz (KI) und deren Anwendungen, wie Chat GPT, Microsoft Co-Pilot, Claude, Gemini, zu nutzen und die Ergebnisse kritisch zu bewerten. Sie beinhaltet die Fähigkeit, effektiv mit KI zu kommunizieren, sowie Kenntnisse über grundlegende KI-Konzepte, Algorithmen und maschinelles Lernen. Außerdem stehen ethische und datenschutzrechtliche Implikationen von KI-Anwendungen im Fokus.\n\nVerwende ausschließlich folgende Abstufungen:\n0 = keine Relevanz / trifft gar nicht zu\n0,3 = geringe Relevanz / teilweise Abdeckung\n0,7 = deutlicher Schwerpunkt\n1 = zentrale Kompetenz des Lernangebots / trifft voll zu\nVerwende ausschließlich diese Kategorien mit den Codierungen 0; 0,3; 0,7; 1\nKeine anderen Werte angeben.', '0.7', '0'),
(14, 'Sprache', 'filter', 'Sprache', 'Sprache, in der der Kurs durchgeführt wird. Dabei verwende immer die deutsche Schreibweise der Sprache. Also Englisch und nicht English.', 'Englisch', 'Deutsch');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `crawl_list`
--

CREATE TABLE `crawl_list` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `master_id` int(11) NOT NULL,
  `url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `markup` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'alt (markup hat sich nicht geändert), neu (llm muss arbeiten)',
  `crawled_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `crawl_master`
--

CREATE TABLE `crawl_master` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `URL` text NOT NULL,
  `Verzeichnis` varchar(256) NOT NULL,
  `Paginierung` varchar(256) NOT NULL,
  `PaginierungsEigenschaft` varchar(256) NOT NULL,
  `PaginierungsStopp` varchar(256) NOT NULL,
  `Detailseite` varchar(256) NOT NULL,
  `customCommands` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`customCommands`)),
  `excludeRegex` text NOT NULL COMMENT 'der reguläre Ausdruck führt zur Verwerfung einer Detailseite, wenn er matcht',
  `includeRegex` text NOT NULL COMMENT 'der reguläre Ausdruck führt zum Akzeptieren einer Detailseite, wenn er matcht',
  `FilterFormular` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Manche Webseiten sollten vor dem scrapen gefiltert werden. Das hier eingegebene JSON führt zum Absenden des Filter-Formulars.' CHECK (json_valid(`FilterFormular`)),
  `Elemente` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`Elemente`)),
  `Ebene` varchar(256) NOT NULL,
  `FieldsPrompt` text NOT NULL,
  `FieldsExample` text NOT NULL,
  `PrePrompt` text NOT NULL,
  `PostPrompt` text NOT NULL,
  `Seite` varchar(256) NOT NULL,
  `Aktiv` tinyint(1) NOT NULL DEFAULT 1,
  `Kommentar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `crawl_master_competency_types`
--

CREATE TABLE `crawl_master_competency_types` (
  `master_id` int(11) NOT NULL,
  `competency_slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `offers`
--

CREATE TABLE `offers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `crawl_list_id` bigint(20) UNSIGNED NOT NULL,
  `url` text NOT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `level` double DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `offer_competencies`
--

CREATE TABLE `offer_competencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `offer_id` bigint(20) UNSIGNED NOT NULL,
  `competency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `score` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `prompt`
--

CREATE TABLE `prompt` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `identifier` varchar(10000) NOT NULL,
  `part` varchar(256) NOT NULL,
  `data` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `prompt`
--

INSERT INTO `prompt` (`id`, `identifier`, `part`, `data`, `created_at`, `updated_at`) VALUES
(1, 'preprompt', '', 'Extrahiere folgende Information des Seminars / Kurses als JSON-Objekt mit folgenden Feldern:', NULL, NULL),
(2, 'title', 'field', 'Titel des Seminars, Kurs oder der Veranstaltung.', NULL, NULL),
(3, 'description', '', 'Kurzbeschreibung des Seminars, Kurs oder der Veranstaltung.', NULL, NULL),
(4, 'provider', '', 'Name des Seminaranbieters. Leerer String wenn keine Angabe gefunden wird.', NULL, NULL),
(10, 'level', '', 'Geschätzte Schwierigkeit / Einstiegshöhe des Seminars, Kurs oder der Veranstaltung. Grundkurse werden leichter eingeschätzt als Kurse für die Erfahrung vorausgesetzt wird. Verwende ausschließlich die Werte 0; 0,5 oder 1\n0 steht für Basis-Kurs, Einsteiger, Anfänger, Grundkurs, etc.\n0.5 steht für Kurse, die nicht klar einzuschätzen sind wie z.B. Austauschkurse\n1 steht für Expertenkurs oder Fortgeschrittene', NULL, NULL),
(11, 'postprompt', '', 'Weil deine Antwort als JSON weiterverarbeitet werden soll, ist es wichtig, dass nur das JSON Objekt ausgegeben wird ohne erklärende Texte oder Hinweise.\nWenn du auf der gegebenen Seite kein Seminar / Kurs findest, oder wenn es sich um eine Übersichtsseite mit mehreren Kursen handelt dann antworte mit FALSE.', NULL, NULL);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indizes für die Tabelle `categories_crawl_master`
--
ALTER TABLE `categories_crawl_master`
  ADD PRIMARY KEY (`categories_slug`,`crawl_master_id`),
  ADD KEY `fk_ccm_crawl` (`crawl_master_id`);

--
-- Indizes für die Tabelle `category_competency_type`
--
ALTER TABLE `category_competency_type`
  ADD PRIMARY KEY (`category_slug`,`competency_type_slug`),
  ADD KEY `idx_competency_type_slug` (`competency_type_slug`);

--
-- Indizes für die Tabelle `competency_types`
--
ALTER TABLE `competency_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_competency_types_slug` (`slug`);

--
-- Indizes für die Tabelle `crawl_list`
--
ALTER TABLE `crawl_list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `crawl_list_url_unique` (`url`(768)) USING BTREE;

--
-- Indizes für die Tabelle `crawl_master`
--
ALTER TABLE `crawl_master`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `crawl_master_competency_types`
--
ALTER TABLE `crawl_master_competency_types`
  ADD PRIMARY KEY (`master_id`,`competency_slug`),
  ADD KEY `idx_competency_slug` (`competency_slug`);

--
-- Indizes für die Tabelle `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offers_webtexts_id_foreign` (`crawl_list_id`) USING BTREE;

--
-- Indizes für die Tabelle `offer_competencies`
--
ALTER TABLE `offer_competencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offer_competencies_offer_id_foreign` (`offer_id`);

--
-- Indizes für die Tabelle `prompt`
--
ALTER TABLE `prompt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `prompt_key` (`identifier`) USING HASH;

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `competency_types`
--
ALTER TABLE `competency_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT für Tabelle `crawl_list`
--
ALTER TABLE `crawl_list`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `crawl_master`
--
ALTER TABLE `crawl_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `offers`
--
ALTER TABLE `offers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `offer_competencies`
--
ALTER TABLE `offer_competencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `prompt`
--
ALTER TABLE `prompt`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `categories_crawl_master`
--
ALTER TABLE `categories_crawl_master`
  ADD CONSTRAINT `fk_ccm_category` FOREIGN KEY (`categories_slug`) REFERENCES `categories` (`slug`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ccm_crawl` FOREIGN KEY (`crawl_master_id`) REFERENCES `crawl_master_BAK` (`id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `category_competency_type`
--
ALTER TABLE `category_competency_type`
  ADD CONSTRAINT `fk_cct_category` FOREIGN KEY (`category_slug`) REFERENCES `categories` (`slug`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cct_competency_type` FOREIGN KEY (`competency_type_slug`) REFERENCES `competency_types` (`slug`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `crawl_master_competency_types`
--
ALTER TABLE `crawl_master_competency_types`
  ADD CONSTRAINT `fk_cmct_competency` FOREIGN KEY (`competency_slug`) REFERENCES `competency_types` (`slug`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cmct_master` FOREIGN KEY (`master_id`) REFERENCES `crawl_master_BAK` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
